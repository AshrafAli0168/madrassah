export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: 'AIzaSyC5WqWCu_xpLhP3Fj_d9DL-5TAaifZeJ_o',
    authDomain: 'madrasa-8e04a.firebaseapp.com',
    databaseURL: 'https://madrasa-8e04a.firebaseio.com',
    projectId: 'madrasa-8e04a',
    storageBucket: 'madrasa-8e04a.appspot.com',
    messagingSenderId: '242891816953',
    appId: '1:242891816953:web:af3147802e87bece13c728',
  },
};
